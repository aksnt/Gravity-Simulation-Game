Note: Processing 4 does not run on Mac OSX Ventura 13.0, please use lower versions or Windows.

1. Increase maximum available memory in Processing 4 as it otherwise throws an outOfMemoryException.
2. Ensure all files are in the same directory (no folders)
3. Simply run the program
4. If you want to add more textures, add to the directory and "TEXTURES" array and the program will automatically incorporate them.